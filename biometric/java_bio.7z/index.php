<?php
error_reporting(0);
header('Access-Control-Allow-Origin: *'); 
//proceed when jar file is okay
//$cmd="java -jar speedpower.jar";
$cmd='java -cp "lib/*;". VideoCaptureDemo ';
exec($cmd,$output);
$x=end($output);
$postData = array(
        "img" => prev($output),
        "base64" => $x
);

echo json_encode($postData, JSON_PRETTY_PRINT);

//unlink("read/".prev($output));
//unlink("write/".prev($output));

?>